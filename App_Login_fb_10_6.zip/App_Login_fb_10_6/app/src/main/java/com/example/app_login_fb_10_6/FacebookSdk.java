package com.example.app_login_fb_10_6;

import android.content.Context;

public class FacebookSdk {
    public static void sdkInitialize(Context applicationContext) {
    }
}
